create procedure pro_reg_user(v_username varchar2, v_password varchar2, st out varchar2) is

begin
savepoint a;
insert into t_user(username,password) values(v_username,v_password);
st:='注册成功！';
commit;

exception
  when others then
    st:='注册失败！' ;
    rollback to a;

end pro_reg_user;

/

