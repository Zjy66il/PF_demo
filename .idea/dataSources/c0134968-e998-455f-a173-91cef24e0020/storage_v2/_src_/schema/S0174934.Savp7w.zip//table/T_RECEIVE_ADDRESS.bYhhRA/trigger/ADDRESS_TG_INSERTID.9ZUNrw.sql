create trigger ADDRESS_TG_INSERTID
    before insert
    on T_RECEIVE_ADDRESS
    for each row
begin
    select T_RECEIVE_ADDRESS_ID_SEQ.nextval into:new.ID from dual;
end;
/

