create trigger BOOK_TG_INSERTID
    before insert
    on T_BOOK
    for each row
begin
    select T_BOOK_ID_SEQ.nextval into:new.ID from dual;
end;
/

