create trigger ORDER_TG_INSERTID
    before insert
    on T_ORDER
    for each row
begin
    select T_ORDER_ID_SEQ.nextval into:new.ID from dual;
end;
/

