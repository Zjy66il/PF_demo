create trigger TRG_ACTION_STME
  after insert or update or delete
  on T_USER
  for each row
declare
  log_username action_log.username%type;
  log_action action_log.action%type;
  log_ip action_log.ip%type;
begin
  if inserting then
    log_action := '注册';
  elsif updating then
    log_action := '修改密码';
  elsif deleting then
    log_action := '用户注销';
  end if;
  log_username := :new.username;
  log_ip := SYS_CONTEXT('USERENV','IP_ADDRESS');
  insert into action_log(username,action,ip) values (log_username,log_action,log_ip);  
 
end trg_action_stme;
/

