create trigger PRODUCT_TG_INSERTID
    before insert
    on T_PRODUCT
    for each row
begin
    select T_PRODUCT_ID_SEQ.nextval into:new.ID from dual;
end;
/

