create function getno_xh2 return varchar2 is
  n integer;
  y varchar2(2);
  vxh varchar2(5);
  Result varchar2(5); 
begin
  y:=to_char(sysdate,'yy');
  select count(*) into n from t_a;
  if n=0 then
    Result:=y||'001';
  else
    select max(xh) into vxh from t_a; 
    vxh:=substr(vxh,3); 
    n:=(to_number(vxh)+1);
    vxh:=to_char(n);
    
    if length(vxh)=1 then
      Result:=y||'00'||vxh;
    end if;  
    if length(vxh)=2 then
      Result:=y||'0'||vxh;
    end if;  
    if length(vxh)=3 then
      Result:=y||vxh;
    end if;    
    if length(vxh)>3 then
      RAISE_APPLICATION_ERROR(-20001,'越界!');
    end if;

  end if;    
  return(Result);
end getno_xh2;
/

