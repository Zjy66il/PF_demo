create trigger ITEM_TG_INSERTID
    before insert
    on T_ITEM
    for each row
begin
    select T_ITEM_ID_SEQ.nextval into:new.ID from dual;
end;
/

