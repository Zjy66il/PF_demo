create function getno_xh return varchar2 is
  n integer;
  vxh varchar2(7);
  Result varchar2(7);
begin
  select count(*) into n from t_a;
  if n=0 then
    Result:='0000001';
  else
    select max(xh) into vxh from t_a;  
    n:=(to_number(vxh)+1);
    vxh:=to_char(n);
    if length(vxh)=1 then
      Result:='000000'||vxh;
    end if;  
    if length(vxh)=2 then
      Result:='00000'||vxh;
    end if;  
    if length(vxh)=3 then
      Result:='0000'||vxh;
    end if;  
    if length(vxh)=4 then
      Result:='000'||vxh;
    end if;  
    if length(vxh)=5 then
      Result:='00'||vxh;
    end if;  
    if length(vxh)=6 then
      Result:='0'||vxh;
    end if;  
    if length(vxh)=7 then
      Result:=vxh;
    end if;
    if length(vxh)>7 then
      RAISE_APPLICATION_ERROR(-20001,'越界!');
    end if;
    
  end if;    
  return(Result);
end getno_xh;
/

