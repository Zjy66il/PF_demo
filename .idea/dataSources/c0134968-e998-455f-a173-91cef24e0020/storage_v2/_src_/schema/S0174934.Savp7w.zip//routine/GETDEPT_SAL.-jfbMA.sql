create function getdept_sal(v_deptno number,v_deptname out varchar2) return number is
  R1 number;
begin
  select DNAME into v_deptname from dept where deptno=v_deptno;
  select sum(SAL) into R1 from emp where deptno=v_deptno;  
  return R1;
  EXCEPTION
    WHEN OTHERS THEN
      R1:=0;
      v_deptname := '失败';
      return R1;
end getdept_sal;
/

